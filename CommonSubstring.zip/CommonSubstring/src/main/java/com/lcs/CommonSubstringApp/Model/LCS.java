package com.lcs.CommonSubstringApp.Model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
@Component
public class LCS {
	
	@JsonProperty("lcs")
	List<Value> lcs ;

	public LCS(List<String> largestCommonSubStrings) {
		lcs = new ArrayList<>() ;
		for(String lcString : largestCommonSubStrings) {
			Value value = new Value() ;
			value.setValue(lcString);
			lcs.add(value) ;
		}
	}

	@JsonProperty("lcs")
	public List<Value> getLcs() {
		return lcs;
	}
	
	@JsonProperty("lcs")
	public void setLcs(List<Value> lcs) {
		this.lcs = lcs;
	}

}

