package com.lcs.CommonSubstringApp.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lcs.CommonSubstringApp.Aggregator.SubstringAppAggregator;
import com.lcs.CommonSubstringApp.Model.LCS;
import com.lcs.CommonSubstringApp.Model.SetOfStrings;
import com.lcs.CommonSubstringApp.Util.ValidatorException;
import com.lcs.CommonSubstringApp.Validator.SubstringAppValidator;

@RestController
public class SubstringAppController {
	
	@Autowired SubstringAppAggregator aggregator ;
	@Autowired SubstringAppValidator validator ;
	
	@PostMapping(value = "/findLargeCommonSubstring", produces = MediaType.APPLICATION_JSON_VALUE)
	public Object findLargestSubstring(@RequestBody SetOfStrings setOfStrings) {
		try {
			validator.validateSetOfStrings(setOfStrings) ;
		}catch(ValidatorException ex) {
			return new ResponseEntity<Object>(ex.getReturnMesssage(),ex.getReturnStatus());
		}
		LCS lcs = aggregator.findLargestCommonSubstring(setOfStrings) ;
		return new ResponseEntity<Object>(lcs,HttpStatus.OK) ;
	}
}
