package com.lcs.CommonSubstringApp.Model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class SetOfStrings {
	
	@JsonProperty("setOfStrings") List<Value> setOfStrings ;

	@JsonProperty("setOfStrings")
	public List<Value> getSetOfStrings() {
		return setOfStrings;
	}

	@JsonProperty("setOfStrings")
	public void setSetOfStrings(List<Value> setOfStrings) {
		this.setOfStrings = setOfStrings;
	}
}

