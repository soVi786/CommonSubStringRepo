package com.lcs.CommonSubstringApp.Aggregator;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.lcs.CommonSubstringApp.Model.LCS;
import com.lcs.CommonSubstringApp.Model.SetOfStrings;
import com.lcs.CommonSubstringApp.Model.Value;

@Component
public class SubstringAppAggregator {

	public LCS findLargestCommonSubstring(SetOfStrings setOfStrings) {
		List<String> listOfStrings = setOfStrings.getSetOfStrings().stream().
				map(Value::getValue).collect(Collectors.toList());
		List<String> commonSubStrings = generateCommonSubStrings(listOfStrings) ;
		String largestCommonSubString = findLargestCommonSubString(commonSubStrings) ;
		List<String> largestCommonSubStrings = findOtherLargerSubStrings(largestCommonSubString,commonSubStrings) ;
		LCS lcs = new LCS(largestCommonSubStrings) ; 
		return lcs ;
	}

	
	private List<String> findOtherLargerSubStrings(String largestCommonSubString, List<String> commonSubStrings) {
		List<String> largestCommonSubStrings =  new ArrayList<>();
		largestCommonSubStrings.add(largestCommonSubString) ;
		for(int i=0; i<commonSubStrings.size(); i++){
			if(largestCommonSubString.length() == commonSubStrings.get(i).length() && !(largestCommonSubString.equals(commonSubStrings.get(i)))){
				largestCommonSubStrings.add(commonSubStrings.get(i));
			}
		}
		return largestCommonSubStrings ;
	}

	List<String> generateCommonSubStrings(List<String> givenList){
		List<String> commonSubStrings =  new ArrayList<>();
		String word = givenList.get(0);
		for(int i=0; i<word.length(); i++){
			for(int j=i+1; j<=word.length(); j++){
				for(int k=1; k<givenList.size(); k++){
					if(givenList.get(k).contains((word.substring(i, j)))){
						if(k == givenList.size()-1){
							commonSubStrings.add((word.substring(i, j)));
						}
					}
					else{
						break;
					}
				}
			}
		}
		return commonSubStrings ;
	}

	String findLargestCommonSubString(List<String> commonSubStrings){
		String largestCommonSubString = commonSubStrings.get(0);
		for(int i=0; i<commonSubStrings.size(); i++){
			if(largestCommonSubString.length() < commonSubStrings.get(i).length()){
				largestCommonSubString = commonSubStrings.get(i);
			}
		}
		return largestCommonSubString ;
	}
}
