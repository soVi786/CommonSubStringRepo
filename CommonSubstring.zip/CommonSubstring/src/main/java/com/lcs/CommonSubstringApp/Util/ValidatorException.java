package com.lcs.CommonSubstringApp.Util;

import org.springframework.http.HttpStatus;

public class ValidatorException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ErrorDetails returnMesssage ;
	HttpStatus returnStatus ;
	
	public ValidatorException(ErrorDetails returnMesssage, HttpStatus returnStatus) {
		super();
		this.returnMesssage = returnMesssage;
		this.returnStatus = returnStatus;
	}
	public ErrorDetails getReturnMesssage() {
		return returnMesssage;
	}
	public void setReturnMesssage(ErrorDetails returnMesssage) {
		this.returnMesssage = returnMesssage;
	}
	public HttpStatus getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(HttpStatus returnStatus) {
		this.returnStatus = returnStatus;
	}
	
}
