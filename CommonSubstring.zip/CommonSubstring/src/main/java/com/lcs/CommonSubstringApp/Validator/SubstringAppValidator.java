package com.lcs.CommonSubstringApp.Validator;

import java.util.HashSet;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.lcs.CommonSubstringApp.Model.SetOfStrings;
import com.lcs.CommonSubstringApp.Model.Value;
import com.lcs.CommonSubstringApp.Util.ErrorDetails;
import com.lcs.CommonSubstringApp.Util.ValidatorException;
@Component
public class SubstringAppValidator {

	public void validateSetOfStrings(SetOfStrings setOfStrings) throws ValidatorException {
		if(null == setOfStrings || null == setOfStrings.getSetOfStrings()) {
			ErrorDetails error = new ErrorDetails("Invalid Input request","403", "Input request should not be empty") ;
			throw new ValidatorException(error,HttpStatus.BAD_REQUEST) ;
		}else if(setOfStrings.getSetOfStrings().isEmpty()) {
			ErrorDetails error = new ErrorDetails("Invalid Input request","403", "Set of String should not be empty") ;
			throw new ValidatorException(error,HttpStatus.BAD_REQUEST) ;
		}else {
			Set<String> setToCheckDuplicates = new HashSet<String>();
			for (Value cursor: setOfStrings.getSetOfStrings()) {
				if (!setToCheckDuplicates.add(cursor.getValue())) {
					ErrorDetails error = new ErrorDetails("Duplicate Fields in request","403", "Set of Strings should not have duplicates") ;
					throw new ValidatorException(error,HttpStatus.BAD_REQUEST) ;
				}
			}
		}

	}

}
