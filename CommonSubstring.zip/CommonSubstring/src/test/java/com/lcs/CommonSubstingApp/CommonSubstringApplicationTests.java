package com.lcs.CommonSubstingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonSubstringApplicationTests {

	@Test
	void contextLoads() {
	}

}
